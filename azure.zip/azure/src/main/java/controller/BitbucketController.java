package controller;

import model.CommitVersion;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.diff.RawTextComparator;
import org.eclipse.jgit.lib.*;
import org.eclipse.jgit.revwalk.RevCommit;
import org.eclipse.jgit.revwalk.RevTree;
import org.eclipse.jgit.revwalk.RevWalk;
import org.eclipse.jgit.transport.UsernamePasswordCredentialsProvider;
import org.eclipse.jgit.diff.DiffEntry;
import org.eclipse.jgit.diff.DiffFormatter;
import org.eclipse.jgit.treewalk.AbstractTreeIterator;
import org.eclipse.jgit.treewalk.CanonicalTreeParser;
import org.eclipse.jgit.treewalk.filter.PathFilter;
import org.eclipse.jgit.util.io.DisabledOutputStream;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class BitbucketController {
    private Git git = null;
    private String folder_name = null;

    public Git getGit(String repositoryUrl, String user, String password, int random){
        try {
            if(git != null)
                return git;
            folder_name = PropFile.getInstance().getLogGitDirectory() +"/git_"+random+"_temp";
            UsernamePasswordCredentialsProvider userCredentials = new UsernamePasswordCredentialsProvider(user, password);
            deleteFileFolder(folder_name);
            git = Git.cloneRepository()
                    .setURI(repositoryUrl)
                    .setDirectory(new File(folder_name))
                    .setCredentialsProvider(userCredentials)
//                    .setNoCheckout(true)
                    .call();
            return git;
        }catch (Exception e){}
        return null;
    }

    public void closeGit(){
        try {
            if(git == null)
                return;
            git.close();

            deleteFileFolder(folder_name);
        }catch (Exception e){
        }
    }

    static void deleteFileFolder(String path) {
        File file = new File(path);
        if (file.exists()) {
            do {
                delete(file);
            } while (file.exists());
        }
    }

    static void delete(File file) {
        if (file.isDirectory()) {
            String fileList[] = file.list();
            if (fileList.length == 0) {
                file.delete();
            } else {
                int size = fileList.length;
                for (int i = 0; i < size; i++) {
                    String fileName = fileList[i];
                    String fullPath = file.getPath() + "/" + fileName;
                    File fileOrFolder = new File(fullPath);
                    delete(fileOrFolder);
                }
            }
        } else {
            file.delete();
        }
    }

    private static AbstractTreeIterator prepareTreeParser
            (Repository repository, String ref) throws IOException {
        // from the commit we can build the tree which allows us to construct the TreeParser
        Ref head = repository.exactRef(ref);
        try (RevWalk walk = new RevWalk(repository)) {
            RevCommit commit = walk.parseCommit(head.getObjectId());
            RevTree tree = walk.parseTree(commit.getTree().getId());

            CanonicalTreeParser treeParser = new CanonicalTreeParser();
            try (ObjectReader reader = repository.newObjectReader()) {
                treeParser.reset(reader, tree.getId());
            }
            if(walk!=null)
                walk.dispose();

            return treeParser;
        }
    }

    public Map<String,ArrayList<CommitVersion>> compareBranchesForRepository(String newBranchStr, String oldBranchStr, HashSet<String> ignoreList) throws GitAPIException, IOException {
        if(git == null)
            return null;
        Repository repo = git.getRepository();
        Ref newBranch = repo.exactRef(newBranchStr);
        Ref oldBranch = repo.exactRef(oldBranchStr);
        if(newBranch == null || oldBranch == null){
            return null;
        }

        Map<String,ArrayList<CommitVersion>> commitsHashMap = new HashMap<>();
        RevWalk walk = new RevWalk(repo);
        List<Ref> branches = git.branchList().call();
        Iterable<RevCommit> commits = git.log().all().call();

        for (RevCommit commit : commits) {
            if(commit.getFullMessage().startsWith("Merge pull request")) //Ignore Merge pull request commits
                continue;

            boolean foundInNew = false;
            boolean foundInOld = false;

            RevCommit targetCommit = walk.parseCommit(repo.resolve(commit.getName()));
            for (Map.Entry<String, Ref> e : repo.getAllRefs().entrySet()) {
                if (e.getKey().equals(newBranchStr)) {
                    if (walk.isMergedInto(targetCommit, walk.parseCommit(e.getValue().getObjectId()))) {
                            foundInNew = true;
                            continue;
                    }
                }

                if (e.getKey().equals(oldBranchStr)) {
                    if (walk.isMergedInto(targetCommit, walk.parseCommit(
                            e.getValue().getObjectId()))) {
                            foundInOld = true;
                    }
                }

            }

                if(foundInOld && !foundInNew) {
                    RevWalk rw = new RevWalk(repo);
                    RevCommit parent = rw.parseCommit(commit.getParent(0).getId());
                    DiffFormatter df = new DiffFormatter(DisabledOutputStream.INSTANCE);
                    df.setRepository(repo);
                    df.setDiffComparator(RawTextComparator.DEFAULT);
                    df.setDetectRenames(true);
                    List<DiffEntry> diffs = df.scan(parent.getTree(), commit.getTree());
                    if(diffs.size() == 1)
                    {
                        DiffEntry diff = diffs.get(0);
                        if(diff.getNewPath().equals("Jenkinsfile.yml"))
                            continue;
                    }

                    AbstractTreeIterator oldTreeParser = prepareTreeParser(git.getRepository(), oldBranchStr);
                    AbstractTreeIterator newTreeParser = prepareTreeParser(git.getRepository(), newBranchStr);
                    //check if the files are updated manually in the newbRanch
                    for (DiffEntry diffo : diffs) {
                        List<DiffEntry> differ = git.diff().
                                setOldTree(oldTreeParser).
                                setNewTree(newTreeParser).
                                setPathFilter(PathFilter.create(diffo.getNewPath())).call();
                                // to filter on Suffix use the following instead
                                //setPathFilter(PathSuffixFilter.create(".java")).
                        if(differ.size() > 0)
                        {

                            for (DiffEntry diff : differ) {
                                ArrayList<CommitVersion> comitHash = commitsHashMap.get(diff.getNewPath());
                                boolean ignore = (ignoreList.contains(commit.getName().substring(0,10)) || ignoreList.contains(commit.getName()));
                                if(comitHash == null)
                                {
                                    comitHash = new ArrayList<>();
                                    comitHash.add(new CommitVersion(commit,diff,ignore));
                                    commitsHashMap.put(diff.getNewPath(),comitHash);
                                }else
                                {
                                    comitHash.add(new CommitVersion(commit,diff,ignore));
                                }
                            }
                        }

                    }
            }
        }
        return commitsHashMap;
    }




}
