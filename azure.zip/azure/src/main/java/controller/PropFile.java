package controller;

import lombok.Data;
import org.yaml.snakeyaml.Yaml;

import java.io.InputStream;
import java.util.Map;
@Data
public class PropFile {
    private static PropFile instanceObject = null;
     private PropFile(){

         Yaml yaml = new Yaml();
         InputStream inputStream = PropFile.class.getClassLoader().getResourceAsStream("application.yml");
         Map<String, String> user = yaml.load(inputStream);
         pcfUser = user.get("pcfUser");
         pcfPassword = user.get("pcfPassword");
         outputDirectory = user.get("outputDirectory");
         inputDirectory = user.get("inputDirectory");
         logGitDirectory = user.get("logGitDirectory");
         logDirectory = user.get("logDirectory");
         templateFileName = user.get("templateFileName");
         bitbucket= user.get("bitbucket");
         Authorization= user.get("Authorization");
         gitRepoPrefix = user.get("gitRepoPrefix");
         commitsLink = user.get("commitsLink");
         securedMode = Boolean.parseBoolean(user.get("securedMode"));


     }
     private String pcfUser;
     private String pcfPassword;
     private String outputDirectory;
     private String inputDirectory;
     private String logGitDirectory;
     private String logDirectory;
     private String templateFileName;
     private String bitbucket;
     private String Authorization;
     private String gitRepoPrefix;
     private String commitsLink;
     private boolean securedMode;

    public static PropFile getInstance() {
        if(instanceObject == null)
            instanceObject = new PropFile();
            return instanceObject;
    }
}
