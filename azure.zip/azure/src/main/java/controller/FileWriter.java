package controller;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashSet;

public class FileWriter {

    public static String createHTMLFile(String jasn, String inputDirectory, String filename,String finalFileName) throws IOException {
        jasn = jasn.replaceAll("'" , "\\\\'");
        Path path = Paths.get(inputDirectory+"/"+filename);
        Path newpath = Paths.get(finalFileName );
        Charset charset = StandardCharsets.UTF_8;
        String content = new String(Files.readAllBytes(path), charset);
        content = content.replaceFirst("#REPLACEDATAWITHJASON", jasn);
        Files.write(newpath, content.getBytes(charset));
        return finalFileName ;
    }


    public static HashSet<String> getIgnoreList(String pathFile) {
        HashSet<String> ignoreList = new HashSet<>();
        if(pathFile == null)
            return ignoreList;

        BufferedReader reader;
        try {
            reader = new BufferedReader(new FileReader( pathFile ));
            String line = reader.readLine();
            while (line != null) {
                ignoreList.add(line);
                line = reader.readLine();
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return ignoreList;
    }


}
