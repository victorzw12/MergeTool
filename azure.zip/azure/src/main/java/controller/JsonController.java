package controller;

import lombok.Data;
import model.CommitVersion;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;

@Data
public class JsonController {
    private String gitPath = null;
    boolean securedMode = true;
    private HashMap<String, String> repo = new HashMap<>();

    public JsonController(String path, boolean securedMode) {
        gitPath = path;
        this.securedMode = securedMode;
        initiateAzureRepo();

    }

    public static String writeJson(Map<String, Map<String, ArrayList<CommitVersion>>> results, String oldBranchStr, String newBranchStr) {
        JSONObject obj = new JSONObject();
        obj.put("size", results.size());
        obj.put("OriginalBranch", oldBranchStr);
        obj.put("TargetBranch", newBranchStr);
        obj.put("DateTime", new Date().getTime());
        JSONArray list = new JSONArray();

        results.forEach((reponame, hash) ->
        {
            JSONObject ms = new JSONObject();
            ms.put("MS", reponame);
            if (hash == null)
                ms.put("BranchExist", false);
            else
                ms.put("BranchExist", true);
            ms.put("COMMITS", getRepoDetails(reponame, hash));
            list.add(ms);

        });
        obj.put("Branches", list);
        return obj.toJSONString();
    }

    private static JSONArray getRepoDetails(String reponame, Map<String, ArrayList<CommitVersion>> hash) {
        JSONArray list = new JSONArray();
        if (hash == null)
            return list;
        hash.forEach((file, commits) -> {
            for (int i = 0; i < commits.size(); i++) {
                JSONObject commitJS = new JSONObject();
                commitJS.put("commitid", commits.get(i).getCommit().getName());
                commitJS.put("owner", commits.get(i).getCommit().getAuthorIdent().getName());
                commitJS.put("datetime", (new Date(commits.get(i).getCommit().getCommitTime() * 1000L)).toString());
                commitJS.put("description", commits.get(i).getCommit().getShortMessage());
                commitJS.put("file", commits.get(i).getDiffEntry().getNewPath());
                commitJS.put("ignore", commits.get(i).isIgnore());
                commitJS.put("commitlink", bulidUrl(reponame, commits.get(i).getCommit().getName()));

                list.add(commitJS);
            }
        });
        return list;
    }

    private static String bulidUrl(String reponame, String name) {
        return PropFile.getInstance().getCommitsLink() + reponame + "/commits/" + name;
    }

    void initiateAzureRepo() {
        try {
//            String input = "{ \"value\": [ { \"id\": \"8c5e6ece-95f7-420c-a712-059ebf6cd342\", \"name\": \"Cellcom.Jet.DB\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/8c5e6ece-95f7-420c-a712-059ebf6cd342\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 9463330, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.DB\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.DB\" }, { \"id\": \"400a89ed-bedf-4203-b618-070c51777124\", \"name\": \"Cellcom.Jet.CM.Test\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/400a89ed-bedf-4203-b618-070c51777124\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 37571, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.CM.Test\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.CM.Test\" }, { \"id\": \"ea6dc8f9-3d18-4f1c-bb84-0c636b2bd110\", \"name\": \"Cellcom.Jet.WORKORDER.API\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/ea6dc8f9-3d18-4f1c-bb84-0c636b2bd110\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 14554501, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.WORKORDER.API\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.WORKORDER.API\" }, { \"id\": \"19fe8768-4537-401a-b80d-0d183d917c00\", \"name\": \"Cellcom.Jet.BillingManagement.API\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/19fe8768-4537-401a-b80d-0d183d917c00\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 50463901, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.BillingManagement.API\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.BillingManagement.API\" }, { \"id\": \"dec3d502-b1ca-47e2-8887-125e5d86ccd0\", \"name\": \"Cellcom.Jet.MobileServices.API\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/dec3d502-b1ca-47e2-8887-125e5d86ccd0\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 53943, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.MobileServices.API\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.MobileServices.API\" }, { \"id\": \"207f5894-4549-458e-8199-15fc28031354\", \"name\": \"Cellcom.Jet.Appointment.API\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/207f5894-4549-458e-8199-15fc28031354\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 228453, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.Appointment.API\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.Appointment.API\" }, { \"id\": \"a1367ecc-7a02-4298-a492-1ca2efcba792\", \"name\": \"Cellcom.Jet.CibbCore\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/a1367ecc-7a02-4298-a492-1ca2efcba792\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 1977995, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.CibbCore\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.CibbCore\" }, { \"id\": \"5e30278c-24c0-4508-b238-1d979cddcef3\", \"name\": \"Cellcom.Jet.Interactions.API\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/5e30278c-24c0-4508-b238-1d979cddcef3\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 67004, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.Interactions.API\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.Interactions.API\" }, { \"id\": \"3cbb7ceb-718f-4b27-ab24-2141fba3f7d2\", \"name\": \"Cellcom.Jet.JobManagement\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/3cbb7ceb-718f-4b27-ab24-2141fba3f7d2\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 98053, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.JobManagement\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.JobManagement\" }, { \"id\": \"ec4f250d-6ec8-4a89-be66-2d62c7087a85\", \"name\": \"Cellcom.Jet.Notifications\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/ec4f250d-6ec8-4a89-be66-2d62c7087a85\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 140730, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.Notifications\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.Notifications\" }, { \"id\": \"0f835d2d-63f2-458c-ab00-335c9fdbce9a\", \"name\": \"Cellcom.Jet.DocumentManagement.API\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/0f835d2d-63f2-458c-ab00-335c9fdbce9a\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 89559, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.DocumentManagement.API\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.DocumentManagement.API\" }, { \"id\": \"4aa7ce6d-7755-4375-8712-3d019a6bee00\", \"name\": \"Cellcom.Jet.Tests\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/4aa7ce6d-7755-4375-8712-3d019a6bee00\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 1557415, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.Tests\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.Tests\" }, { \"id\": \"b6ce0aee-825e-48bf-9296-3e6b50da09e1\", \"name\": \"Cellcom.Jet.DB.RefData\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/b6ce0aee-825e-48bf-9296-3e6b50da09e1\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/master\", \"size\": 620201, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.DB.RefData\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.DB.RefData\" }, { \"id\": \"a62e6e65-53a3-43db-8557-45cd73a3a0a3\", \"name\": \"Cellcom.Jet.Common\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/a62e6e65-53a3-43db-8557-45cd73a3a0a3\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 5151291, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.Common\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.Common\" }, { \"id\": \"568db770-4c34-4966-9efe-480214dfbb00\", \"name\": \"Cellcom.Jet.ApiGateway\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/568db770-4c34-4966-9efe-480214dfbb00\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 3425858, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.ApiGateway\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.ApiGateway\" }, { \"id\": \"0eb5b71f-0e8b-4cc4-ba78-514ce6650538\", \"name\": \"Cellcom.Jet.Opportunity.API\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/0eb5b71f-0e8b-4cc4-ba78-514ce6650538\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 921632, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.Opportunity.API\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.Opportunity.API\" }, { \"id\": \"bd2bf140-6a7e-45fe-8cc7-5153d0465e84\", \"name\": \"Cellcom.Jet.External.Reference.Data.API\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/bd2bf140-6a7e-45fe-8cc7-5153d0465e84\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 195694, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.External.Reference.Data.API\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.External.Reference.Data.API\" }, { \"id\": \"e0902321-b668-4315-91e5-53a65b76cd88\", \"name\": \"Cellcom.Jet.AdjustmentManagement.API\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/e0902321-b668-4315-91e5-53a65b76cd88\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 980509, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.AdjustmentManagement.API\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.AdjustmentManagement.API\" }, { \"id\": \"c88713ac-bbfc-4553-951e-60b43e596d35\", \"name\": \"Cellcom.Jet.DB.SecurityData\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/c88713ac-bbfc-4553-951e-60b43e596d35\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 252868, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.DB.SecurityData\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.DB.SecurityData\" }, { \"id\": \"773ee85b-3887-4542-936b-6389893c1290\", \"name\": \"Cellcom.Jet.Infra\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/773ee85b-3887-4542-936b-6389893c1290\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/master\", \"size\": 13634804, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.Infra\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.Infra\" }, { \"id\": \"c5cef8e4-4226-4a86-8312-714b178119b7\", \"name\": \"Cellcom.Jet.ResourceManagement.API\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/c5cef8e4-4226-4a86-8312-714b178119b7\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 171857, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.ResourceManagement.API\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.ResourceManagement.API\" }, { \"id\": \"26819ac5-1983-4e7e-8f28-7381fec177a9\", \"name\": \"AccountWebAPI\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/26819ac5-1983-4e7e-8f28-7381fec177a9\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/master\", \"size\": 805121, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/AccountWebAPI\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/AccountWebAPI\" }, { \"id\": \"a4aabbfb-9ea0-4802-9bd3-7b395cfa4d97\", \"name\": \"Cellcom.Jet.DB.STG.BI\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/a4aabbfb-9ea0-4802-9bd3-7b395cfa4d97\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/master\", \"size\": 13849, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.DB.STG.BI\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.DB.STG.BI\" }, { \"id\": \"81f89573-c4c7-4d38-8342-9b0f470e95e6\", \"name\": \"Cellcom.Jet.UI\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/81f89573-c4c7-4d38-8342-9b0f470e95e6\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 65064248, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.UI\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.UI\" }, { \"id\": \"fc061cc0-35db-478d-82e5-9d56795c2df9\", \"name\": \"Cellcom.Jet.360.API\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/fc061cc0-35db-478d-82e5-9d56795c2df9\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 1706778, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.360.API\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.360.API\" }, { \"id\": \"b949ae6d-d1cc-47f6-826b-a1c0db60abb2\", \"name\": \"Cellcom.Jet.CustomerManagement.API\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/b949ae6d-d1cc-47f6-826b-a1c0db60abb2\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 4425479, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.CustomerManagement.API\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.CustomerManagement.API\" }, { \"id\": \"98d059ec-0aae-44d4-86f7-a51b7d50e86c\", \"name\": \"Cellcom.Jet.CPQ.API\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/98d059ec-0aae-44d4-86f7-a51b7d50e86c\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 4471601, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.CPQ.API\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.CPQ.API\" }, { \"id\": \"ca63e444-7116-4c5d-9183-a67dc8f77b11\", \"name\": \"Cellcom.Jet.FollowUp.API\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/ca63e444-7116-4c5d-9183-a67dc8f77b11\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 991924, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.FollowUp.API\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.FollowUp.API\" }, { \"id\": \"bc2a27e4-18fc-400c-8e8d-bb0e014248c7\", \"name\": \"Cellcom.Jet.SecurityManagement.API\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/bc2a27e4-18fc-400c-8e8d-bb0e014248c7\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 621610, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.SecurityManagement.API\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.SecurityManagement.API\" }, { \"id\": \"0d9dd68b-0cd9-4957-8751-bb97181246ed\", \"name\": \"Cellcom.Jet.Reference.Data.API\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/0d9dd68b-0cd9-4957-8751-bb97181246ed\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 1268758, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.Reference.Data.API\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.Reference.Data.API\" }, { \"id\": \"23d0cd7a-d588-4d25-92f7-be45758c043b\", \"name\": \"Cellcom.Jet.Chat.Webhooks.API\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/23d0cd7a-d588-4d25-92f7-be45758c043b\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 205628, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.Chat.Webhooks.API\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.Chat.Webhooks.API\" }, { \"id\": \"19652e19-af53-4047-9ca5-ca683f1618e0\", \"name\": \"Cellcom.Jet.interfaceHub\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/19652e19-af53-4047-9ca5-ca683f1618e0\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 247748, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.interfaceHub\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.interfaceHub\" }, { \"id\": \"9ee3f333-8f81-43e3-9cb7-d293b42a2be0\", \"name\": \"Cellcom.Jet.Lead.API\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/9ee3f333-8f81-43e3-9cb7-d293b42a2be0\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 857032, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.Lead.API\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.Lead.API\" }, { \"id\": \"b4ab87a8-b678-45cc-a8c7-e170b754cc9c\", \"name\": \"Cellcom.Jet.UserManagement.API\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/b4ab87a8-b678-45cc-a8c7-e170b754cc9c\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 778102, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.UserManagement.API\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.UserManagement.API\" }, { \"id\": \"e775755f-2215-4c92-8c74-e760b9603035\", \"name\": \"Cellcom.Jet.FinancialActivities.API\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/e775755f-2215-4c92-8c74-e760b9603035\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 439801, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.FinancialActivities.API\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.FinancialActivities.API\" }, { \"id\": \"08df987d-8ce5-4395-972a-e98143b5b810\", \"name\": \"Cellcom.Jet.Application.Data.API\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/08df987d-8ce5-4395-972a-e98143b5b810\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 5793751, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.Application.Data.API\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.Application.Data.API\" }, { \"id\": \"24f8441e-4b04-4189-85fd-ed643fd8d8c0\", \"name\": \"Cellcom.Jet.Catalog.API\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/24f8441e-4b04-4189-85fd-ed643fd8d8c0\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 156552, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.Catalog.API\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.Catalog.API\" }, { \"id\": \"0ce2e527-aedf-4344-9cd6-f00e69bfbe20\", \"name\": \"Cellcom.Jet.Templates\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/0ce2e527-aedf-4344-9cd6-f00e69bfbe20\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 100756, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.Templates\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.Templates\" }, { \"id\": \"9e04e903-d017-4055-b790-fd7caeae902b\", \"name\": \"Cellcom.Jet.WebSocket.API\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/162e01a5-6154-4299-9d1f-071ccd96bdae/_apis/git/repositories/9e04e903-d017-4055-b790-fd7caeae902b\", \"project\": { \"id\": \"162e01a5-6154-4299-9d1f-071ccd96bdae\", \"name\": \"CellcomJet\", \"description\": \"CRM Project\", \"url\": \"http://tfs-prod:8080/tfs/CellcomCollection/_apis/projects/162e01a5-6154-4299-9d1f-071ccd96bdae\", \"state\": \"wellFormed\", \"revision\": 4025608, \"visibility\": \"private\" }, \"defaultBranch\": \"refs/heads/Dev\", \"size\": 74811, \"remoteUrl\": \"http://tfs-prod:8080/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.WebSocket.API\", \"sshUrl\": \"ssh://tfs-prod:22/tfs/CellcomCollection/CellcomJet/_git/Cellcom.Jet.WebSocket.API\" } ], \"count\": 39 }";
//            JSONObject response = readJsonFile(input);
            JSONObject response = getHTML(gitPath,0);
            long size = (long) response.get("count");
            updateGitRepositories(size, response);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void initiateRepo() {
//        testing();
        try {
            boolean isLastPage = false;
            long index = 1;
            while (!isLastPage) {
                JSONObject response = null;
                if (securedMode) {
                    response = getHTMLSecured(gitPath, index);
                } else {
                    response = getHTML(gitPath, index);
                }

                isLastPage = (boolean) response.get("isLastPage");
                if (!isLastPage) {
                    index = (long) response.get("nextPageStart");
                }
                long size = (long) response.get("size");

                updateGitRepositories(size, response);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void testing() {
        repo.put("amdocs-digital", "https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/amdocs-digital.git");

/*
        repo.put("line-of-service-sa-v1","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/line-of-service-sa-v1.git");
        repo.put("bill-image-ms-v1","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/bill-image-ms-v1.git");
        repo.put("amdocs-digital","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/amdocs-digital.git");

        repo.put("ban-transaction-log-audit-ms-v1","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/ban-transaction-log-audit-ms-v1.git");
        repo.put("collection-info-sa-v1","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/collection-info-sa-v1.git");
        repo.put("billing-accounts-ms-v1","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/billing-accounts-ms-v1.git");
        repo.put("promotions-ms-v2","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/promotions-ms-v2.git");
        repo.put("migration-order-ms-v1","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/migration-order-ms-v1.git");


        repo.put("account-activity-log-publisher-ms-v1","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/account-activity-log-publisher-ms-v1.git");
        repo.put("account-usage-summary-sa-v2","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/account-usage-summary-sa-v2.git");
        repo.put("account-verification-sa-v1","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/account-verification-sa-v1.git");
        repo.put("achilles-core","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/achilles-core.git");
        repo.put("address-data-sync-ms-v1","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/address-data-sync-ms-v1.git");
        repo.put("address-ms-v1","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/address-ms-v1.git");
        repo.put("address-transactions-gg","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/address-transactions-gg.git");
        repo.put("adjustments-sa-v1","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/adjustments-sa-v1.git");
        repo.put("age-bucket-sa-v1","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/age-bucket-sa-v1.git");
        repo.put("aggregate-discount-request-ep-v1","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/aggregate-discount-request-ep-v1.git");
        repo.put("amdocs-digital","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/amdocs-digital.git");
        repo.put("amdocs-digital-backup","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/amdocs-digital-backup.git");
        repo.put("amdocs-digital-prod","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/amdocs-digital-prod.git");
        repo.put("amdocs-microapps","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/amdocs-microapps.git");
        repo.put("amdocs-widgets","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/amdocs-widgets.git");
        repo.put("amqpproducerlibrarystarter","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/amqpproducerlibrarystarter.git");
        repo.put("api-billing-preferences-sa","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/api-billing-preferences-sa.git");
        repo.put("apigeeswaggers","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/apigeeswaggers.git");
        repo.put("aradjustment-dayone-v1","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/aradjustment-dayone-v1.git");
        repo.put("atwork-dayone-v1","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/atwork-dayone-v1.git");
        repo.put("atwork-deepio-integration-ms-v1","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/atwork-deepio-integration-ms-v1.git");
        repo.put("audit-log-ms-v1","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/audit-log-ms-v1.git");
        repo.put("autopay-dayone-v1","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/autopay-dayone-v1.git");
        repo.put("autopay-eligibility-ms-v1","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/autopay-eligibility-ms-v1.git");
        repo.put("autopay-transactions-gg","https://SVC_DEV_AMDOCSPCF@bitbucket.service.edp.t-mobile.com/scm/adms/autopay-transactions-gg.git");
        repo.clear();*/
    }

    private void updateGitRepositories(long size, JSONObject json) {
        JSONArray repos = (JSONArray) json.get("value");
        for (Object r : repos) {
            JSONObject repoJson = (JSONObject) r;
            String reponame = (String) (repoJson.get("name"));
            String link = (String) (repoJson.get("remoteUrl"));
            repo.put(reponame, link);
        }

//        for (int i = 0; i < size; i++) {
//            String reponame = (String) ((JSONObject) ((JSONArray) json.get("value")).get(i)).get("slug");
//            String link = "";
//            int indx = 0;
//            if (((JSONObject) ((JSONArray) ((JSONObject) ((JSONObject) ((JSONArray) json.get("values")).get(i)).get("links")).get("clone")).get(1)).get("name").equals("http"))
//                indx = 1;
//            link = (String) ((JSONObject) ((JSONArray) ((JSONObject) ((JSONObject) ((JSONArray) json.get("values")).get(i)).get("links")).get("clone")).get(indx)).get("href");
//            repo.put(reponame, link);
//        }
    }

    public JSONObject getHTMLSecured(String urlToRead, long index) throws Exception {
        HttpsURLConnection conn = null;
        URL url = new URL(urlToRead + "?start=" + index);
        conn = (HttpsURLConnection) url.openConnection();
        conn.addRequestProperty("Authorization", PropFile.getInstance().getAuthorization());
        SSLContext sc = SSLContext.getInstance("SSL");
        sc.init(null, new TrustManager[]{new TrustAnyTrustManager()}, new java.security.SecureRandom());
//        conn.setSSLSocketFactory(sc.getSocketFactory());
        InputStream is = conn.getInputStream();
        InputStreamReader isr = new InputStreamReader(is);
        BufferedReader br = new BufferedReader(isr);

        String inputLine;
        StringBuilder result = new StringBuilder();
        while ((inputLine = br.readLine()) != null) {
            result.append(inputLine);
        }
        br.close();
        return readJsonFile(result.toString());
    }

    public JSONObject getHTML(String urlToRead, long index ) throws Exception {
        HttpURLConnection conn = null;
        URL url = new URL(urlToRead);
        conn = (HttpURLConnection) url.openConnection();
        conn.addRequestProperty("Authorization", PropFile.getInstance().getAuthorization());
        SSLContext sc = SSLContext.getInstance("SSL");
        sc.init(null, new TrustManager[]{new TrustAnyTrustManager()}, new java.security.SecureRandom());
//        conn.setSSLSocketFactory(sc.getSocketFactory());
        InputStream is = conn.getInputStream();
        InputStreamReader isr = new InputStreamReader(is);
        BufferedReader br = new BufferedReader(isr);

        String inputLine;
        StringBuilder result = new StringBuilder();
        while ((inputLine = br.readLine()) != null) {
            result.append(inputLine);
        }
        br.close();
        return readJsonFile(result.toString());
    }

    public static JSONObject readJsonFile(String path) throws ParseException {
        JSONParser parser = new JSONParser();
        JSONObject json = (JSONObject) parser.parse(path);
        return json;
    }

}
