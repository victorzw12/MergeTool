package model;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.eclipse.jgit.diff.DiffEntry;
import org.eclipse.jgit.revwalk.RevCommit;
@Data
@AllArgsConstructor
public class CommitVersion {
    private RevCommit commit;
    private DiffEntry diffEntry;
    private boolean ignore;
}
