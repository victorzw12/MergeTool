package model;

import lombok.AllArgsConstructor;
import lombok.Data;
import javax.persistence.*;
import java.util.Date;
@AllArgsConstructor
@Data
@Table(name = "DIGITAL_DEPLOYMENT_VERSIONS")
public class Version {

    @Column(name = "VERSION_ID")
    int versionId;
    @Column(name = "VERSION_NAME")
    String versionName;
    @Column(name = "VERSION_YEAR")
    int versionYear;
    @Column(name = "VERSION_MONTH")
    int versionMonth;
    @Column(name = "CODE_DROP")
    int codeDrop;
    @Column(name = "SYS_CREATION_DATE")
    Date sysCreationDate;
    @Column(name = "SYS_UPDATE_DATE")
    Date sysUpdateDate;
    @Column(name = "USER_ID")
    String userId;

}
