import controller.BitbucketController;
import controller.FileWriter;
import controller.JsonController;
import controller.PropFile;
import excel.FlexibleExcelWriter;
import model.CommitVersion;
import org.eclipse.jgit.api.errors.GitAPIException;
import java.io.IOException;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class GetBranchesDifferences {
    private static FileHandler fh = null;
    static Logger logger = Logger.getLogger(GetBranchesDifferences.class.getName());
    static int random = (int)(Math.random() * 999999);
    static private SimpleDateFormat format = new SimpleDateFormat("yyyy-M-d_HHmmss");

    public static void main(String[] args) {

        initLog();
        Paths.get(PropFile.getInstance().getInputDirectory()+"/"+PropFile.getInstance().getTemplateFileName());
        if(args.length < 2)
        {
            logger.severe("Number of Arguments is incorrect...");
            logger.severe("Arg[0] - Source Branch 'release/1908'");
            logger.severe("Arg[1] - Target Branch 'release/1910'");
            logger.severe("Arg[2] - (Optional) path of file contain list of ignore commit ids");
            return;
        }
        // Get Repositories
        logger.info("Starting process : " + format.format(Calendar.getInstance().getTime()));
        JsonController jsonController = new JsonController(PropFile.getInstance().getBitbucket(),PropFile.getInstance().isSecuredMode());

        // Check diff
//        BasicConfigurator.configure();

        String oldBranchStr = PropFile.getInstance().getGitRepoPrefix()+args[0];//"/release/1908";
        String newBranchStr = PropFile.getInstance().getGitRepoPrefix()+args[1];//"release/1910";
//        String newBranchStr = "refs/heads/"+args[1];//"release/1910";
        //String newBranchStr = "refs/heads/master";
//        String oldBranchStr = "refs/heads/"+args[0];//"/release/1908";


        logger.info("Arg[0] 'Old Brnach' : " + oldBranchStr);
        logger.info("Arg[1] 'New Brnach' : " + newBranchStr);

        String ignoreListPathfile = null;
        if(args.length > 2) {
            ignoreListPathfile = args[2];
            logger.info("Arg[2] 'Ignore List' : " + ignoreListPathfile);
        }
        HashSet<String> ignoreList =  FileWriter.getIgnoreList(ignoreListPathfile);
        logger.info("Ignore List size : " + ignoreList.size());


        String user = PropFile.getInstance().getPcfUser();
        String password = PropFile.getInstance().getPcfPassword();
        boolean secureMode=PropFile.getInstance().isSecuredMode();

        BitbucketController bitbucketController ;
        HashMap<String,String> repo =  jsonController.getRepo();
        logger.info("Repo size : " + repo.size());

        Map<String, Map<String,ArrayList<CommitVersion>>> results = new HashMap<>();


        try {
            int i = 0 ;
        for(Map.Entry<String, String> entry : repo.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            bitbucketController = getVersionsFromBitbucket(value,user,password,random);
            Map<String,ArrayList<CommitVersion>> tmp = bitbucketController.compareBranchesForRepository(newBranchStr,oldBranchStr,ignoreList);
            results.put(key,tmp);

            if(tmp == null)
                logger.info("Repository #" + i++ + " : " + key + "   ( doesn't impacted )");
            else
                logger.info("Repository #" + i++ + " : " + key + "   ( impacted files : : "+tmp.size() +" )");
            bitbucketController.closeGit();
        }

        String finalFileName = generateOutputFileName(newBranchStr, oldBranchStr);
        String jasn = "";
        try {
                jasn = JsonController.writeJson(results, oldBranchStr, newBranchStr);
                String outputHtmlName = FileWriter.createHTMLFile(jasn, PropFile.getInstance().getInputDirectory(), PropFile.getInstance().getTemplateFileName(), finalFileName);
        }catch (Exception e){
            logger.severe("Error : " + e.getMessage());
            logger.warning("Output : " + jasn);
        }

        FlexibleExcelWriter.writeExcelFile(results,finalFileName);
        logger.info("New report created : " + finalFileName);
        System.out.println (finalFileName.replaceAll(".html",""));
        logger.info("Process Finish Successfully: " + format.format(Calendar.getInstance().getTime()));

        } catch (GitAPIException e) {
            e.printStackTrace();
            logger.severe("Process Failed: " + e.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
            logger.severe("Process Failed: " + e.getMessage());
        }
    }

    private static String generateOutputFileName(String newBranchStr, String oldBranchStr) {
        String from = oldBranchStr.replaceAll("/" ,"_");
        String to= newBranchStr.replaceAll("/" ,"_");
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
        Date date = new Date();
        return PropFile.getInstance().getOutputDirectory()+"/"+from + "_"+to+ "_"+formatter.format(date)+".html";
    }

    private static void initLog() {
        try {
            fh = new FileHandler(PropFile.getInstance().getLogDirectory() + "/"+format.format(Calendar.getInstance().getTime())+"_"+random+".log");
        } catch (Exception e) {
            e.printStackTrace();
        }

        fh.setFormatter(new SimpleFormatter());
        logger.addHandler(fh);

    }

    public static BitbucketController getVersionsFromBitbucket(String REMOTE_URL, String user, String password, int random) {
        BitbucketController bitbucketController = new BitbucketController();
        bitbucketController.getGit(REMOTE_URL,user,password,random);
        return bitbucketController;
    }
}
