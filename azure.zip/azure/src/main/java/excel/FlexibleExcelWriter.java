package excel;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import model.CommitVersion;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;


public class FlexibleExcelWriter {
    private static Workbook workbook;
    private static Sheet sheet;
    private static String file_name;
    private static void prepareExcelFile(String excelFilePath) throws IOException {
        file_name = excelFilePath.replaceAll(".html" , ".xls");
        workbook = getWorkbook(file_name);
        sheet = workbook.createSheet();
        createHeaderRow(sheet);
    }

    private static void closeExcelFile() throws IOException {

        try (FileOutputStream outputStream = new FileOutputStream(file_name)) {
            workbook.write(outputStream);
        }
    }


    private static void createHeaderRow(Sheet sheet) {

        CellStyle cellStyle = sheet.getWorkbook().createCellStyle();
        Font font = sheet.getWorkbook().createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 16);
        cellStyle.setFont(font);

        Row row = sheet.createRow(0);
        Cell cellMSName = row.createCell(0);
        cellMSName.setCellStyle(cellStyle);
        cellMSName.setCellValue("MS Name");

        Cell cellCommitId = row.createCell(1);
        cellCommitId.setCellStyle(cellStyle);
        cellCommitId.setCellValue("Commit ID");

        Cell cellOwner = row.createCell(2);
        cellOwner.setCellStyle(cellStyle);
        cellOwner.setCellValue("Owner");

        Cell cellTime = row.createCell(3);
        cellTime.setCellStyle(cellStyle);
        cellTime.setCellValue("Time");

        Cell cellFileName = row.createCell(4);
        cellFileName.setCellStyle(cellStyle);
        cellFileName.setCellValue("File Name");

        Cell cellDescription = row.createCell(5);
        cellDescription.setCellStyle(cellStyle);
        cellDescription.setCellValue("Description");

        Cell cellStatus = row.createCell(6);
        cellStatus.setCellStyle(cellStyle);
        cellStatus.setCellValue("Status");

    }


    private static Workbook getWorkbook(String excelFilePath)
            throws IOException {
        Workbook workbook = null;

        if (excelFilePath.endsWith("xls")) {
            workbook = new HSSFWorkbook();
        } else {
            throw new IllegalArgumentException("The specified file is not Excel file");
        }

        return workbook;
    }



    public static String writeExcelFile(Map<String, Map<String, ArrayList<CommitVersion>>> results, String fileName) {
        if(fileName == null || !fileName.contains(".html"))
            return null;
        try {
            prepareExcelFile(fileName);
            results.forEach((reponame, hash) ->
            {
                writeCol(reponame,hash);
            });

            closeExcelFile();
            return file_name;
        } catch (IOException e) {
            return null;
        }

    }

    private static void writeCol(String reponame, Map<String, ArrayList<CommitVersion>> hash) {
        if(hash == null)
            return;


        AtomicInteger rowCount = new AtomicInteger();
        hash.forEach((file, commits) -> {
            for(int i = 0 ; i < commits.size() ; i++) {
//                if(!commits.get(i).isIgnore()) { //Dont add the ignore list to the excel
                    Row row = sheet.createRow(rowCount.incrementAndGet());
                    Cell cell = row.createCell(0);
                    cell.setCellValue(reponame);

                    cell = row.createCell(1);
                    cell.setCellValue(commits.get(i).getCommit().getName());

                    cell = row.createCell(2);
                    cell.setCellValue(commits.get(i).getCommit().getAuthorIdent().getName());

                    cell = row.createCell(3);
                    cell.setCellValue((new Date(commits.get(i).getCommit().getCommitTime() * 1000L)).toString());

                    cell = row.createCell(4);
                    cell.setCellValue(commits.get(i).getDiffEntry().getNewPath());


                    cell = row.createCell(5);
                    cell.setCellValue(commits.get(i).getCommit().getShortMessage());

                    String Status = "Missing";
                    if (commits.get(i).isIgnore())
                        Status = "Ignore";
                    cell = row.createCell(6);
                    cell.setCellValue(Status);
//                }
            }
        });
    }
}
